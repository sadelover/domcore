
// -*- c++ -*-
// ***********************************************************
//
// Copyright (C) 2013 R&B
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Module:   
// Author:   david
// Date:     2010/7/13
// Revision: 1.0
//
// ***********************************************************


#ifndef DLLDEFILE_H
#define DLLDEFILE_H

#define DLLEXPORT 
#define DLLIMPORT _declspec(dllimport)

#endif
