
#include "stdafx.h"
#include "DBInterfaceExp.h"
#include "RunningRecordOperation.h"


//////////////////////////////////////////////////////////////////////////

//COperationRecord::COperationRecord()
//{
//}
//
//CWarningRecord::CWarningRecord()
//{
//
//}