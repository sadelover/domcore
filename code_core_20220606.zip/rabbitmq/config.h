/* vim:set ft=c ts=2 sw=2 sts=2 et cindent: */
#ifndef CONFIG_H
#define CONFIG_H

#ifndef __cplusplus
# define inline __inline
#endif

/* #undef HAVE_HTONLL */

#define HAVE_SELECT

/* #undef HAVE_POLL */

#define AMQ_PLATFORM "Windows-10.0.15063"

#endif /* CONFIG_H */
